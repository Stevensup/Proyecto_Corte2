package co.edu.unbosque.controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;

import co.edu.unbosque.model.ContactoAmigo;
import co.edu.unbosque.view.Panel_Amigos;
import co.edu.unbosque.view.Panel_Contactos;
import co.edu.unbosque.view.Panel_Estadisticas;
import co.edu.unbosque.view.Panel_Inicio;
import co.edu.unbosque.view.Panel_Lista;
import co.edu.unbosque.view.Ventana;

public class Controlleer implements ActionListener {
	
	
	private ContactoAmigo Camigo;
    // private ContactoTrabajo Ctrabajo;
	
	private Panel_Amigos panelAmigos;
	private Panel_Contactos panelContactos;
	private Panel_Lista panelLista;
	private Panel_Estadisticas panelEstad;
	private Panel_Inicio panelInicio;
	
	private Ventana ven;
	
	public Controlleer() {
		
		 Camigo = new ContactoAmigo(null, null, null, null);
	        // Ctrabajo = new ContactoTrabajo(null, null, null, null);
		 
		 panelAmigos = new Panel_Amigos ();
		 panelContactos = new Panel_Contactos ();
		 panelLista = new Panel_Lista ();
		 panelEstad = new Panel_Estadisticas ();
		 panelInicio = new Panel_Inicio ();
		 
		 ven = new Ventana();
		 
		 start();
		 
	}
	
	public void start() {
		
		setListeners();
		
	}
	
	//Establecer los listeners de eventos para los botones de la interfaz de ventana.
	public void setListeners () {
		ven.getPanelInicio().getBotAmigos().addActionListener(this);
		ven.getPanelInicio().getBotAmigos().setActionCommand("BtnAmigos");
		
		ven.getPanelInicio().getBotContactos().addActionListener(this);
		ven.getPanelInicio().getBotContactos().setActionCommand("BtnContactos");
		
		ven.getPanelInicio().getBotLista().addActionListener(this);
		ven.getPanelInicio().getBotLista().setActionCommand("BtnLista");
		
		ven.getPanelInicio().getBotEstad().addActionListener(this);
		ven.getPanelInicio().getBotEstad().setActionCommand("BtnEstad");
		
		//Registrar Amigo
		ven.getPanelAmigos().getbtRegistrarAmigo().addActionListener(this);
		ven.getPanelAmigos().getbtRegistrarAmigo().setActionCommand("btRegistrarAmigo");
				
		//Registrar Contacto
		ven.getPanelContactos().getbtRegistrarContacto().addActionListener(this);
		ven.getPanelContactos().getbtRegistrarContacto().setActionCommand("btRegistrarContacto");
		
		//Buscar Amigo
		ven.getPanelAmigos().getBtBuscarAmigo().addActionListener(this);
		ven.getPanelAmigos().getBtBuscarAmigo().setActionCommand("btBuscarAmigo");
		
		
		//Botones de regresar entre paneles:
		ven.getPanelAmigos().getbtRegresarAmigo().addActionListener(this);
		ven.getPanelAmigos().getbtRegresarAmigo().setActionCommand("btRegresarAmigo");
		
		
		ven.getPanelContactos().getbtRegresarContacto().addActionListener(this);
		ven.getPanelContactos().getbtRegresarContacto().setActionCommand("btRegresarContacto");
				
		
		ven.getPanelLista().getbtRegresarLista().addActionListener(this);
		ven.getPanelLista().getbtRegresarLista().setActionCommand("btRegresarLista");
				
		
				
		ven.getPanelEstad().getbtRegresarEstad().addActionListener(this);
		ven.getPanelEstad().getbtRegresarEstad().setActionCommand("btRegresarEstad");
		
	}
	
	
	
	

	@Override
	public void actionPerformed(ActionEvent e) {
		
		int option = 0;
		switch(e.getActionCommand()) {
		
		
		//Cambiar de interfaz 
		case "BtnAmigos":
			//Cambiar de interfaz a la del amigo
			ven.getPanelInicio().setVisible(false);
			ven.getPanelAmigos().setVisible(true);
			break;
			
		case "BtnContactos":
			
			ven.getPanelInicio().setVisible(false);
			ven.getPanelContactos().setVisible(true);
			break;
			
		case "BtnLista":
			
			ven.getPanelInicio().setVisible(false);
			ven.getPanelLista().setVisible(true);
			break;
			
		case "BtnEstad":
			
			ven.getPanelInicio().setVisible(false);
			ven.getPanelEstad().setVisible(true);
			break;
		
		//Botones de registrar:
			
		case "btRegistrarAmigo":
			String nombre = ven.getPanelAmigos().getJtNombre().getText();
			String telefono = ven.getPanelAmigos().getJtTelefono().getText();
			String pais= ven.getPanelAmigos().getJtPais().getText(); 
			String correo= ven.getPanelAmigos().getJtCorreo().getText();
			 Camigo.agregarContacto(nombre, telefono, correo, pais);
			
			//metodo para el JTextArea:
				ven.getPanelAmigos().getJtaResultadosAmigo().append("NOMBRE: "+nombre + "\n ");
				ven.getPanelAmigos().getJtaResultadosAmigo().append("TELEFONO: "+telefono + "\n");
				ven.getPanelAmigos().getJtaResultadosAmigo().append("PAIS: "+pais + "\n");
				ven.getPanelAmigos().getJtaResultadosAmigo().append("CORREO: "+correo + "\n");
				break;
				
		case "btRegistrarContacto":
			String nombreTrabajo = ven.getPanelContactos().getJtNombre().getText();
			String telefonoTrabajo = ven.getPanelContactos().getJtTelefono().getText();
			String paisTrabajo= ven.getPanelContactos().getJtPais().getText(); 
			String correoTrabajo= ven.getPanelContactos().getJtCorreo().getText();
			 //Camigo.agregarContacto(nombre, telefono, correo, pais);
			
			//metodo para el JTextArea:
				ven.getPanelContactos().getJtaResultadosContact().append("NOMBRE: "+nombreTrabajo + "\n ");
				ven.getPanelContactos().getJtaResultadosContact().append("TELEFONO: "+telefonoTrabajo + "\n");
				ven.getPanelContactos().getJtaResultadosContact().append("PAIS: "+paisTrabajo + "\n");
				ven.getPanelContactos().getJtaResultadosContact().append("CORREO: "+correoTrabajo + "\n");		
				break;
				
		
				
				
		case "btBuscarAmigo":
			String nombreAmigo = JOptionPane.showInputDialog(null, "Ingrese el nombre del amigo a buscar:");
		    ContactoAmigo amigoEncontrado = new ContactoAmigo(nombreAmigo, null, null, null).buscarAmigo(nombreAmigo);
		    if (amigoEncontrado != null) {
		        JOptionPane.showMessageDialog(null, "Se encontró el amigo: " + amigoEncontrado.toString());
		    } else {
		        JOptionPane.showMessageDialog(null, "No se encontró el amigo con ese nombre.");
		    }
		    break;
				
				
		case "btListaDeContactos":		
			break;		
			
			
		
			
				
				
		
				
				
		case "btRegresarAmigo":
			ven.getPanelAmigos().setVisible(false);
			ven.getPanelInicio().setVisible(true);
			break;
			
		case "btRegresarContacto":
			ven.getPanelContactos().setVisible(false);
			ven.getPanelInicio().setVisible(true);
			break;	
			
		case "btRegresarLista":
			ven.getPanelLista().setVisible(false);
			ven.getPanelInicio().setVisible(true);
			break;
			
		case "btRegresarEstad":
			ven.getPanelEstad().setVisible(false);
			ven.getPanelInicio().setVisible(true);
			break;
			
		case "btSalir":
			break;
		
			
			
			
			
			
			
				
		}
		
		
		
		
		
	}

	
	











	public ContactoAmigo getCamigo() {
		return Camigo;
	}













	public void setCamigo(ContactoAmigo camigo) {
		Camigo = camigo;
	}













	public Panel_Amigos getPanelAmigos() {
		return panelAmigos;
	}













	public void setPanelAmigos(Panel_Amigos panelAmigos) {
		this.panelAmigos = panelAmigos;
	}













	public Panel_Contactos getPanelContactos() {
		return panelContactos;
	}













	public void setPanelContactos(Panel_Contactos panelContactos) {
		this.panelContactos = panelContactos;
	}













	public Panel_Lista getPanelLista() {
		return panelLista;
	}













	public void setPanelLista(Panel_Lista panelLista) {
		this.panelLista = panelLista;
	}













	public Panel_Estadisticas getPanelEstad() {
		return panelEstad;
	}













	public void setPanelEstad(Panel_Estadisticas panelEstad) {
		this.panelEstad = panelEstad;
	}













	public Panel_Inicio getPanelInicio() {
		return panelInicio;
	}













	public void setPanelInicio(Panel_Inicio panelInicio) {
		this.panelInicio = panelInicio;
	}













	public Ventana getVen() {
		return ven;
	}













	public void setVen(Ventana ven) {
		this.ven = ven;
	}
	
	 


	}


	


