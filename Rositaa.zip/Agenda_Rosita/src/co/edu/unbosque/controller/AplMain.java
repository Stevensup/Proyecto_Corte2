package co.edu.unbosque.controller;

public class AplMain {

	public static void main(String[] args) {
		Controlleer control = new Controlleer();
		control.start();
	}

}
