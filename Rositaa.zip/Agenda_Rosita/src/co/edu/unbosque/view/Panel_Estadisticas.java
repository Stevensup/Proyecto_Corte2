package co.edu.unbosque.view;

import java.awt.Font;

import javax.swing.JButton;
import javax.swing.JPanel;

public class Panel_Estadisticas extends JPanel{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JButton btRegistrarEstad;
	private JButton btRegresarEstad; 
	
	
	public Panel_Estadisticas() {
setLayout(null);
		
		start();
		
		setVisible(false);
	}
	public void start() {
		//Regresar
				btRegresarEstad = new JButton("Regresar");
				btRegresarEstad.setBounds(520, 410, 200, 30);
				btRegresarEstad.setFont(new Font("arial", Font.PLAIN, 30));
				add(btRegresarEstad);
				
				
				
	}
	
	
	public JButton getbtRegistrarEstad() {
		return btRegistrarEstad;
	}
	public void setbtRegistrarEstad(JButton btRegistrarEstad) {
		this.btRegistrarEstad = btRegistrarEstad;
	}
	public JButton getbtRegresarEstad() {
		return btRegresarEstad;
	}
	public void setbtRegresarEstad(JButton btRegresarEstad) {
		this.btRegresarEstad = btRegresarEstad;
	}
	

}


