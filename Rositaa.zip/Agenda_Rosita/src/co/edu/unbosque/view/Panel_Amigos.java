package co.edu.unbosque.view;

import java.awt.Font;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class Panel_Amigos extends JPanel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JLabel jlaNombre;
	private JLabel jlaTelefono;
	private JLabel jlaPais;
	private JLabel jlaCorreo;
	
	private JTextField jtNombre;
	private JTextField jtTelefono;
	private JTextField jtPais;
	private JTextField jtCorreo;
	
	private JButton btRegistrarAmigo;
	private JButton btRegresarAmigo;
	private JButton btEditarAmigo;
	private JButton btBuscarAmigo;
	
	private JTextArea JtaResultadosAmigo;
	public Panel_Amigos() {
		setLayout(null);
		
		start();
		
		setVisible(false);
	}
	public void start() {
		
		//ETIQUETAS
		jlaNombre = new JLabel("Nombre: ");
		jlaNombre.setBounds(10, 10, 200, 100);
		jlaNombre.setFont(new Font("Times New Roman", Font.PLAIN, 30));
		add(jlaNombre);
		
		jlaTelefono = new JLabel("Telefono: ");
		jlaTelefono.setBounds(10, 50, 250, 200);
		jlaTelefono.setFont(new Font("Times New Roman", Font.PLAIN, 30));
		add(jlaTelefono);
		
		jlaPais = new JLabel("Pais: ");
		jlaPais.setBounds(10, 150, 250, 200);
		jlaPais.setFont(new Font("Times New Roman", Font.PLAIN, 30));
		add(jlaPais);
		
		jlaCorreo = new JLabel("Correo: ");
		jlaCorreo.setBounds(10, 250, 250, 200);
		jlaCorreo.setFont(new Font("Times New Roman", Font.PLAIN, 30));
		add(jlaCorreo);
		
		
		//ESPACIOS DE TEXTO
		jtNombre = new JTextField("");
		jtNombre.setBounds(225, 45, 125, 30);
		jtNombre.setFont(new Font("arial", Font.PLAIN, 15));
		add(jtNombre);
		
		
		jtTelefono = new JTextField();
		jtTelefono.setBounds(225, 135, 125, 30);
		jtTelefono.setFont(new Font("arial", Font.PLAIN, 15));
		add(jtTelefono);
		
		jtPais = new JTextField();
		jtPais.setBounds(225, 240, 125, 30);
		jtPais.setFont(new Font("arial", Font.PLAIN, 15));
		add(jtPais);
		
		jtCorreo = new JTextField();
		jtCorreo.setBounds(225, 340, 125, 30);
		jtCorreo.setFont(new Font("arial", Font.PLAIN, 15));
		add(jtCorreo);
		
		
		//BOTON Registrar
		btRegistrarAmigo = new JButton("Registrar");
		btRegistrarAmigo.setActionCommand("btRegistrarAmigo");
		btRegistrarAmigo.setBounds(300, 410, 200, 30);
		btRegistrarAmigo.setFont(new Font("arial", Font.PLAIN, 30));
		add(btRegistrarAmigo);
		
		btEditarAmigo = new JButton("Editar");
		btEditarAmigo.setActionCommand("btEditarAmigo");
		btEditarAmigo.setBounds(730, 50, 200, 30);
		btEditarAmigo.setFont(new Font("arial", Font.PLAIN, 30));
		add(btEditarAmigo);
		
		btBuscarAmigo = new JButton("Buscar");		
		btBuscarAmigo.setActionCommand("btBuscarAmigo");
		btBuscarAmigo.setBounds(730, 300, 200, 30);
		btBuscarAmigo.setFont(new Font("arial", Font.PLAIN, 30));
		add(btBuscarAmigo);
		
		
		//Regresar
		btRegresarAmigo = new JButton("Regresar");
		btRegresarAmigo.setBounds(520, 410, 200, 30);
		btRegresarAmigo.setFont(new Font("arial", Font.PLAIN, 30));
		add(btRegresarAmigo);
		
		JtaResultadosAmigo = new JTextArea("Usuarios registrados" );
		JtaResultadosAmigo.setBounds(400, 10, 320, 360);
		btRegresarAmigo.setFont(new Font("arial", Font.PLAIN, 30));
		add(JtaResultadosAmigo);
		
		
	
}
	public JLabel getJlaNombre() {
		return jlaNombre;
	}
	public void setJlaNombre(JLabel jlaNombre) {
		this.jlaNombre = jlaNombre;
	}
	public JLabel getJlaTelefono() {
		return jlaTelefono;
	}
	public void setJlaTelefono(JLabel jlaTelefono) {
		this.jlaTelefono = jlaTelefono;
	}
	public JLabel getJlaPais() {
		return jlaPais;
	}
	public void setJlaPais(JLabel jlaPais) {
		this.jlaPais = jlaPais;
	}
	public JLabel getJlaCorreo() {
		return jlaCorreo;
	}
	public void setJlaCorreo(JLabel jlaCorreo) {
		this.jlaCorreo = jlaCorreo;
	}
	public JTextField getJtNombre() {
		return jtNombre;
	}
	public void setJtNombre(JTextField jtNombre) {
		this.jtNombre = jtNombre;
	}
	public JTextField getJtTelefono() {
		return jtTelefono;
	}
	public void setJtTelefono(JTextField jtTelefono) {
		this.jtTelefono = jtTelefono;
	}
	public JTextField getJtPais() {
		return jtPais;
	}
	public void setJtPais(JTextField jtPais) {
		this.jtPais = jtPais;
	}
	public JTextField getJtCorreo() {
		return jtCorreo;
	}
	public void setJtCorreo(JTextField jtCorreo) {
		this.jtCorreo = jtCorreo;
	}
	public JButton getbtRegistrarAmigo() {
		return btRegistrarAmigo;
	}
	public void setbtRegistrarAmigo(JButton btRegistrarAmigo) {
		this.btRegistrarAmigo = btRegistrarAmigo;
	}
	public JButton getbtRegresarAmigo() {
		return btRegresarAmigo;
	}
	public void setbtRegresarAmigo(JButton btRegresarAmigo) {
		this.btRegresarAmigo = btRegresarAmigo;
	}
	public JTextArea getJtaResultadosAmigo() {
		return JtaResultadosAmigo;
	}
	public void setJtaResultadosAmigo(JTextArea JtaResultadosAmigo) {
		this.JtaResultadosAmigo = JtaResultadosAmigo;
	}
	public JButton getBtEditarAmigo() {
		return btEditarAmigo;
	}
	public void setBtEditarAmigo(JButton btEditarAmigo) {
		this.btEditarAmigo = btEditarAmigo;
	}
	public JButton getBtBuscarAmigo() {
		return btBuscarAmigo;
	}
	public void setBtBuscarAmigo(JButton btBuscarAmigo) {
		this.btBuscarAmigo = btBuscarAmigo;
	}
	public JButton getBtRegistrarAmigo() {
		return btRegistrarAmigo;
	}
	public void setBtRegistrarAmigo(JButton btRegistrarAmigo) {
		this.btRegistrarAmigo = btRegistrarAmigo;
	}
	public JButton getBtRegresarAmigo() {
		return btRegresarAmigo;
	}
	public void setBtRegresarAmigo(JButton btRegresarAmigo) {
		this.btRegresarAmigo = btRegresarAmigo;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	
	

}
