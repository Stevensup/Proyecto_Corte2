package co.edu.unbosque.view;

import java.awt.Font;

import javax.swing.JButton;
import javax.swing.JPanel;

public class Panel_Lista extends JPanel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JButton btRegistrarLista;
	private JButton btRegresarLista; 
	private JButton btVerAmigos;
	private JButton btVerContactos;
   
	
	public Panel_Lista() {
setLayout(null);
		
		start();
		
		setVisible(false);
	}
	public void start() {
		//Regresar
				btRegresarLista = new JButton("Regresar");
				btRegresarLista.setBounds(520, 410, 200, 30);
				btRegresarLista.setFont(new Font("arial", Font.PLAIN, 30));
				add(btRegresarLista);
				
				btVerAmigos = new JButton("Ver amigos registrados");
				btVerAmigos.setActionCommand("btVerAmigos");
				btVerAmigos.setBounds(30, 50, 400, 100);
				btVerAmigos.setFont(new Font("arial", Font.PLAIN, 30));  
				add(btVerAmigos);
				
				btVerContactos = new JButton("Ver contactos registrados");
				btVerContactos.setActionCommand("btVerContactos");
				btVerContactos.setBounds(500, 50, 400, 100);
				btVerContactos.setFont(new Font("arial", Font.PLAIN, 30));
				add(btVerContactos);
				
				
	}
	public JButton getbtRegistrarLista() {
		return btRegistrarLista;
	}
	public void setbtRegistrarLista(JButton btRegistrarLista) {
		this.btRegistrarLista = btRegistrarLista;
	}
	public JButton getbtRegresarLista() {
		return btRegresarLista;
	}
	public void setbtRegresarLista(JButton btRegresarLista) {
		this.btRegresarLista = btRegresarLista;
	}
	public JButton getBtVerAmigos() {
		return btVerAmigos;
	}
	public void setBtVerAmigos(JButton btVerAmigos) {
		this.btVerAmigos = btVerAmigos;
	}
	public JButton getBtVerContactos() {
		return btVerContactos;
	}
	public void setBtVerContactos(JButton btVerContactos) {
		this.btVerContactos = btVerContactos;
	}
	

}
