package co.edu.unbosque.view;

import java.awt.Color;
import java.awt.Font;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Panel_Inicio extends JPanel{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JLabel titulo;
	private JLabel textElection;
	
	private JButton botAmigos;
	private JButton botContactos;
	private JButton botLista;
	private JButton botEstad;
	
	public Panel_Inicio() {
		setLayout(null);
		
		funcionar();
	}
	
	public void funcionar() {
		
		titulo = new JLabel("ROSITA-PLUS");
		titulo.setBounds(230, 80, 600, 60);
		titulo.setOpaque(true);
		titulo.setBackground(Color.LIGHT_GRAY);
		titulo.setFont(new Font("arial", Font.BOLD, 77));
		add(titulo);
		
		textElection = new JLabel("¿Que te gustaria registrar?");
		textElection.setBounds(340, 310, 200, 50);
		textElection.setOpaque(true);
		textElection.setBackground(Color.LIGHT_GRAY);
		textElection.setFont(new Font("arial", Font.BOLD, 15));
		add(textElection);
		
		botAmigos = new JButton("AMIGOS");
		botAmigos.setBounds(50, 250, 200, 50);
		botAmigos.setOpaque(true);
		botAmigos.setBackground(Color.WHITE);
		botAmigos.setFont(new Font("arial", Font.BOLD, 10));
		add(botAmigos);
		
		botContactos = new JButton("Contactos");
		botContactos.setBounds(280, 250, 200, 50);
		botContactos.setOpaque(true);
		botContactos.setBackground(Color.WHITE);
		botContactos.setFont(new Font("arial", Font.BOLD, 10));
		add(botContactos);
		
		botLista = new JButton("Lista");
		botLista.setBounds(510, 250, 200, 50);
		botLista.setOpaque(true);
		botLista.setBackground(Color.WHITE);
		botLista.setFont(new Font("arial", Font.BOLD, 10));
		add(botLista);
		
		botEstad = new JButton("Estadisticas");
		botEstad.setBounds(740, 250, 185, 50);
		botEstad.setOpaque(true);
		botEstad.setBackground(Color.WHITE);
		botEstad.setFont(new Font("arial", Font.BOLD, 10));
		add(botEstad);
	}

	public JLabel getTitulo() {
		return titulo;
	}

	public void setTitulo(JLabel titulo) {
		this.titulo = titulo;
	}

	public JLabel getTextElection() {
		return textElection;
	}

	public void setTextElection(JLabel textElection) {
		this.textElection = textElection;
	}

	public JButton getBotAmigos() {
		return botAmigos;
	}

	public void setBotAmigos(JButton botAmigos) {
		this.botAmigos = botAmigos;
	}

	public JButton getBotContactos() {
		return botContactos;
	}

	public void setBotContactos(JButton botContactos) {
		this.botContactos = botContactos;
	}

	public JButton getBotLista() {
		return botLista;
	}

	public void setBotLista(JButton botLista) {
		this.botLista = botLista;
	}

	public JButton getBotEstad() {
		return botEstad;
	}

	public void setBotEstad(JButton botEstad) {
		this.botEstad = botEstad;
	}
	


}
