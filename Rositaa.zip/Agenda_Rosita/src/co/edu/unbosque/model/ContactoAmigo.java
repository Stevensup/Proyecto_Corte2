package co.edu.unbosque.model;

import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;



public class ContactoAmigo implements Serializable {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String nombre;
    private String telefono;
    private String correo;
    private String pais;
    private List<ContactoAmigo> contactos;

    public ContactoAmigo(String nombre, String telefono, String correo, String pais) {
        this.nombre = nombre;
        this.telefono = telefono;
        this.correo = correo;
        this.pais = pais;
        this.contactos = contactos;
    }

    public void agregarContacto(String nombreAmigo, String telefonoAmigo, String correoAmigo, String paisAmigo) {
        AgendaAmigos agenda = leerDeArchivoData();
        if (agenda == null) {
            agenda = new AgendaAmigos();
        }
        ContactoAmigo nuevoContacto = new ContactoAmigo(nombreAmigo, telefonoAmigo, correoAmigo, paisAmigo);
        agenda.getContactosAmigos().add(nuevoContacto);
        guardarEnArchivoData(agenda);
        System.out.println(agenda.toString());
    }

    public ContactoAmigo buscarAmigo(String nombre) {
        AgendaAmigos agenda = leerDeArchivoData();
        if (agenda != null) {
            for (ContactoAmigo c : agenda.getContactosAmigos()) {
                if (c.getNombre().equalsIgnoreCase(nombre)) {
                    return c;
                }
            }
        }
        return null;
    }
    
    
    

    public List<ContactoAmigo> getContactos() {
		return contactos;
	}

	public void setContactos(List<ContactoAmigo> contactos) {
		this.contactos = contactos;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public void listarContactos() {
        System.out.println("Lista de contactos amigos:");
        AgendaAmigos agenda = leerDeArchivoData();
        if (agenda != null) {
            for (ContactoAmigo contacto : agenda.getContactosAmigos()) {
                System.out.println(contacto.toString());
            }
        } else {
            System.out.println("La lista de contactos de amigos está vacía.");
        }
    }
    
    public void editarContacto(String nombre, String telefono, String correo, String pais) {
        AgendaAmigos agenda = leerDeArchivoData();
        if (agenda != null) {
            for (ContactoAmigo c : agenda.getContactosAmigos()) {
                if (c.getNombre().equalsIgnoreCase(nombre)) {
                    c.setTelefono(telefono);
                    c.setCorreo(correo);
                    c.setPais(pais);
                    guardarEnArchivoData(agenda);
                    System.out.println("Contacto editado exitosamente.");
                    return;
                }
            }
            System.out.println("No se encontró ningún contacto con el nombre ingresado.");
        }
    }   
    
    public AgendaAmigos leerDeArchivoData() {
        AgendaAmigos agenda = null;
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream("amigos.data"))) {
            agenda = (AgendaAmigos) ois.readObject();
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Error al leer la lista de contactos de amigos del archivo amigos.data: " + e.getMessage());
        }
        return agenda;
    }
    
    public void guardarEnArchivoData(AgendaAmigos agenda) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("amigos.data"))) {
            oos.writeObject(agenda);
        } catch (IOException e) {
            System.out.println("Error al guardar la lista de contactos de amigos en el archivo amigos.data: " + e.getMessage());
        }
    }
    
    public List<ContactoAmigo> getTodosAmigos(){
    	List<ContactoAmigo> contactos = new ArrayList<ContactoAmigo>();
    	
    	String basePath = new File("").getAbsolutePath();
    	
    	DataInputStream input;
    	
    	try {
    		input = new DataInputStream(new FileInputStream (basePath + "amigos.data"));
    		do {
    			ContactoAmigo contact = new ContactoAmigo(nombre, pais, telefono, correo);
    			contact.setNombre(input.readUTF());
    			contact.setPais(input.readUTF());
    			contact.setTelefono(input.readUTF());
    			contact.setCorreo(input.readUTF());
    			
    			
    		}while (input.available() !=0);
    		input.close();
    		return contactos;
    	}catch (IOException e) {
    		e.printStackTrace();
    		return null;
    	}
    }
    
    

    public String getNombre() {
        return this.nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getTelefono() {
        return this.telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getCorreo() {
        return this.correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getPais() {
        return this.pais;
    }

    public void setPais(String pais) {
        this.pais = pais;
    }

    @Override
        public String toString() {
            return "Nombre: " + nombre + ", Teléfono: " + telefono + ", Correo: " + correo + ", País: " + pais;
        }


		
	

}

