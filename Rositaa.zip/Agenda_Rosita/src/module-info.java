/**
 * 
 */
/**
 * @author steven
 *
 */
module Agenda_Rosita {
	requires java.desktop;
}