package co.edu.unbosque.view;

import java.awt.Font;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class Panel_Amigos extends JPanel{
	private JLabel jlaNombre;
	private JLabel jlaTelefono;
	private JLabel jlaPais;
	private JLabel jlaCorreo;
	
	private JTextField jtNombre;
	private JTextField jtTelefono;
	private JTextField jtPais;
	private JTextField jtCorreo;
	
	private JButton btRegistrar1;
	private JButton btRegresar1;
	
	private JTextArea JtaResultados1;
	public Panel_Amigos() {
		setLayout(null);
		
		start();
		
		setVisible(false);
	}
	public void start() {
		
		//ETIQUETAS
		jlaNombre = new JLabel("Nombre: ");
		jlaNombre.setBounds(10, 10, 200, 100);
		jlaNombre.setFont(new Font("Times New Roman", Font.PLAIN, 30));
		add(jlaNombre);
		
		jlaTelefono = new JLabel("Telefono: ");
		jlaTelefono.setBounds(10, 50, 250, 200);
		jlaTelefono.setFont(new Font("Times New Roman", Font.PLAIN, 30));
		add(jlaTelefono);
		
		jlaPais = new JLabel("Pais: ");
		jlaPais.setBounds(10, 150, 250, 200);
		jlaPais.setFont(new Font("Times New Roman", Font.PLAIN, 30));
		add(jlaPais);
		
		jlaCorreo = new JLabel("Correo: ");
		jlaCorreo.setBounds(10, 250, 250, 200);
		jlaCorreo.setFont(new Font("Times New Roman", Font.PLAIN, 30));
		add(jlaCorreo);
		
		
		//ESPACIOS DE TEXTO
		jtNombre = new JTextField("");
		jtNombre.setBounds(225, 45, 125, 30);
		jtNombre.setFont(new Font("arial", Font.PLAIN, 15));
		add(jtNombre);
		
		
		jtTelefono = new JTextField();
		jtTelefono.setBounds(225, 135, 125, 30);
		jtTelefono.setFont(new Font("arial", Font.PLAIN, 15));
		add(jtTelefono);
		
		jtPais = new JTextField();
		jtPais.setBounds(225, 240, 125, 30);
		jtPais.setFont(new Font("arial", Font.PLAIN, 15));
		add(jtPais);
		
		jtCorreo = new JTextField();
		jtCorreo.setBounds(225, 340, 125, 30);
		jtCorreo.setFont(new Font("arial", Font.PLAIN, 15));
		add(jtCorreo);
		
		
		//BOTON Registrar
		btRegistrar1 = new JButton("Registrar");
		btRegistrar1.setActionCommand("btRegistrar1");
			
		btRegistrar1.setBounds(300, 410, 200, 30);
		btRegistrar1.setFont(new Font("arial", Font.PLAIN, 30));
		add(btRegistrar1);
		
		//Regresar
		btRegresar1 = new JButton("Regresar");
		btRegresar1.setBounds(520, 410, 200, 30);
		btRegresar1.setFont(new Font("arial", Font.PLAIN, 30));
		add(btRegresar1);
		
		JtaResultados1 = new JTextArea("Usuarios registrados" );
		JtaResultados1.setBounds(400, 10, 320, 360);
		btRegresar1.setFont(new Font("arial", Font.PLAIN, 30));
		add(JtaResultados1);
		
	
}
	public JLabel getJlaNombre() {
		return jlaNombre;
	}
	public void setJlaNombre(JLabel jlaNombre) {
		this.jlaNombre = jlaNombre;
	}
	public JLabel getJlaTelefono() {
		return jlaTelefono;
	}
	public void setJlaTelefono(JLabel jlaTelefono) {
		this.jlaTelefono = jlaTelefono;
	}
	public JLabel getJlaPais() {
		return jlaPais;
	}
	public void setJlaPais(JLabel jlaPais) {
		this.jlaPais = jlaPais;
	}
	public JLabel getJlaCorreo() {
		return jlaCorreo;
	}
	public void setJlaCorreo(JLabel jlaCorreo) {
		this.jlaCorreo = jlaCorreo;
	}
	public JTextField getJtNombre() {
		return jtNombre;
	}
	public void setJtNombre(JTextField jtNombre) {
		this.jtNombre = jtNombre;
	}
	public JTextField getJtTelefono() {
		return jtTelefono;
	}
	public void setJtTelefono(JTextField jtTelefono) {
		this.jtTelefono = jtTelefono;
	}
	public JTextField getJtPais() {
		return jtPais;
	}
	public void setJtPais(JTextField jtPais) {
		this.jtPais = jtPais;
	}
	public JTextField getJtCorreo() {
		return jtCorreo;
	}
	public void setJtCorreo(JTextField jtCorreo) {
		this.jtCorreo = jtCorreo;
	}
	public JButton getBtRegistrar1() {
		return btRegistrar1;
	}
	public void setBtRegistrar1(JButton btRegistrar1) {
		this.btRegistrar1 = btRegistrar1;
	}
	public JButton getBtRegresar1() {
		return btRegresar1;
	}
	public void setBtRegresar1(JButton btRegresar1) {
		this.btRegresar1 = btRegresar1;
	}
	public JTextArea getJtaResultados1() {
		return JtaResultados1;
	}
	public void setJtaResultados1(JTextArea jtaResultados1) {
		JtaResultados1 = jtaResultados1;
	}
}