package co.edu.unbosque.view;

import java.awt.Font;

import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JTextArea;

public class Panel_VerLista extends JPanel {
	
	private JButton btRegistrar3;
	private JButton btRegresar3; 
	
	
	public Panel_VerLista() {
setLayout(null);
		
		start();
		
		setVisible(false);
	}
	public void start() {
		//Regresar
				btRegresar3 = new JButton("Regresar");
				btRegresar3.setBounds(520, 410, 200, 30);
				btRegresar3.setFont(new Font("arial", Font.PLAIN, 30));
				add(btRegresar3);
				
				
	}
	public JButton getBtRegistrar3() {
		return btRegistrar3;
	}
	public void setBtRegistrar3(JButton btRegistrar3) {
		this.btRegistrar3 = btRegistrar3;
	}
	public JButton getBtRegresar3() {
		return btRegresar3;
	}
	public void setBtRegresar3(JButton btRegresar3) {
		this.btRegresar3 = btRegresar3;
	}
	

}
