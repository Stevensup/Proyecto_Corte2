package co.edu.unbosque.view;

import java.awt.Font;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class Panel_Contactos extends JPanel {
	private JLabel jlaNombre;
	private JLabel jlaTelefono;
	private JLabel jlaPais;
	private JLabel jlaCorreo;
	
	private JTextField jtNombre;
	private JTextField jtTelefono;
	private JTextField jtPais;
	private JTextField jtCorreo;
	
	private JButton btRegistrar2;
	private JButton btRegresar2;
	
	private JTextArea JtaResultados2;
	public Panel_Contactos() {
		setLayout(null);
		
		start();
		
		setVisible(false);
	}
	public void start() {
		
		//ETIQUETAS
		jlaNombre = new JLabel("Nombre: ");
		jlaNombre.setBounds(10, 10, 200, 100);
		jlaNombre.setFont(new Font("Times New Roman", Font.PLAIN, 30));
		add(jlaNombre);
		
		jlaTelefono = new JLabel("Telefono: ");
		jlaTelefono.setBounds(10, 50, 250, 200);
		jlaTelefono.setFont(new Font("Times New Roman", Font.PLAIN, 30));
		add(jlaTelefono);
		
		jlaPais = new JLabel("Pais: ");
		jlaPais.setBounds(10, 150, 250, 200);
		jlaPais.setFont(new Font("Times New Roman", Font.PLAIN, 30));
		add(jlaPais);
		
		jlaCorreo = new JLabel("Correo: ");
		jlaCorreo.setBounds(10, 250, 250, 200);
		jlaCorreo.setFont(new Font("Times New Roman", Font.PLAIN, 30));
		add(jlaCorreo);
		
		
		//ESPACIOS DE TEXTO
		jtNombre = new JTextField("");
		jtNombre.setBounds(225, 45, 125, 30);
		jtNombre.setFont(new Font("arial", Font.PLAIN, 15));
		add(jtNombre);
		
		
		jtTelefono = new JTextField();
		jtTelefono.setBounds(225, 135, 125, 30);
		jtTelefono.setFont(new Font("arial", Font.PLAIN, 15));
		add(jtTelefono);
		
		jtPais = new JTextField();
		jtPais.setBounds(225, 240, 125, 30);
		jtPais.setFont(new Font("arial", Font.PLAIN, 15));
		add(jtPais);
		
		jtCorreo = new JTextField();
		jtCorreo.setBounds(225, 340, 125, 30);
		jtCorreo.setFont(new Font("arial", Font.PLAIN, 15));
		add(jtCorreo);
		
		
		//BOTON Registrar
		btRegistrar2 = new JButton("Registrar");
		btRegistrar2.setActionCommand("btRegistrar2");
			
		btRegistrar2.setBounds(300, 410, 200, 30);
		btRegistrar2.setFont(new Font("arial", Font.PLAIN, 30));
		add(btRegistrar2);
		
		//Regresar
		btRegresar2 = new JButton("Regresar");
		btRegresar2.setBounds(520, 410, 200, 30);
		btRegresar2.setFont(new Font("arial", Font.PLAIN, 30));
		add(btRegresar2);
		
		JtaResultados2 = new JTextArea("Usuarios registrados" );
		JtaResultados2.setBounds(400, 10, 320, 360);
		btRegresar2.setFont(new Font("arial", Font.PLAIN, 30));
		add(JtaResultados2);
		
	}
	public JLabel getJlaNombre() {
		return jlaNombre;
	}
	public void setJlaNombre(JLabel jlaNombre) {
		this.jlaNombre = jlaNombre;
	}
	public JLabel getJlaTelefono() {
		return jlaTelefono;
	}
	public void setJlaTelefono(JLabel jlaTelefono) {
		this.jlaTelefono = jlaTelefono;
	}
	public JLabel getJlaPais() {
		return jlaPais;
	}
	public void setJlaPais(JLabel jlaPais) {
		this.jlaPais = jlaPais;
	}
	public JLabel getJlaCorreo() {
		return jlaCorreo;
	}
	public void setJlaCorreo(JLabel jlaCorreo) {
		this.jlaCorreo = jlaCorreo;
	}
	public JTextField getJtNombre() {
		return jtNombre;
	}
	public void setJtNombre(JTextField jtNombre) {
		this.jtNombre = jtNombre;
	}
	public JTextField getJtTelefono() {
		return jtTelefono;
	}
	public void setJtTelefono(JTextField jtTelefono) {
		this.jtTelefono = jtTelefono;
	}
	public JTextField getJtPais() {
		return jtPais;
	}
	public void setJtPais(JTextField jtPais) {
		this.jtPais = jtPais;
	}
	public JTextField getJtCorreo() {
		return jtCorreo;
	}
	public void setJtCorreo(JTextField jtCorreo) {
		this.jtCorreo = jtCorreo;
	}
	public JButton getbtRegistrar2() {
		return btRegistrar2;
	}
	public void setbtRegistrar2(JButton btRegistrar22) {
		this.btRegistrar2 = btRegistrar22;
	}
	public JButton getBtRegresar2() {
		return btRegresar2;
	}
	public void setBtRegresar2(JButton btRegresar2) {
		this.btRegresar2 = btRegresar2;
	}
	public JTextArea getJtaResultados2() {
		return JtaResultados2;
	}
	public void setJtaResultados2(JTextArea jtaResultados2) {
		JtaResultados2 = jtaResultados2;
	}
	
	


}
