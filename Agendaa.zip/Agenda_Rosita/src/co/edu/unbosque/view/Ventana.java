package co.edu.unbosque.view;

import java.awt.Color;

import javax.swing.JFrame;




public class Ventana extends JFrame{
	
	private Panel_Amigos panelAmigos;
	private Panel_Contactos panelContactos;
	private Panel_VerLista panelLista;
	private Panel_VerEstadisticas panelEstad;
	private Panel_Inicio panelInicio;
	
	public Ventana() {
		setTitle("AGENDA-ROSITA");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(950, 500);
		getContentPane().setLayout(null);
		getContentPane().setBackground(Color.WHITE);
		
		IngresoDePaneles();
		
		setResizable(true);
		setLocationRelativeTo(null);
		setVisible(true);
	}
	public void IngresoDePaneles() {
		panelInicio = new Panel_Inicio();
		panelInicio.setBounds(1, 0, 950, 500); 
		getContentPane().add(panelInicio);
		panelInicio.setBackground(Color.LIGHT_GRAY);
		
		panelAmigos = new Panel_Amigos();
		panelAmigos.setBounds(1, 0, 950, 500);
		getContentPane().add(panelAmigos);
		panelAmigos.setBackground(Color.LIGHT_GRAY);
		
		panelContactos = new Panel_Contactos();
		panelContactos.setBounds(1, 0, 950, 500);
		getContentPane().add(panelContactos);
		panelContactos.setBackground(Color.LIGHT_GRAY);
		
		panelLista = new Panel_VerLista();
		panelLista.setBounds(1, 0, 950, 500);
		getContentPane().add(panelLista);
		panelLista.setBackground(Color.LIGHT_GRAY);
		
		panelEstad = new Panel_VerEstadisticas();
		panelEstad.setBounds(1, 0, 950, 500);
		getContentPane().add(panelEstad);
		panelEstad.setBackground(Color.LIGHT_GRAY);
		
	}
	public Panel_Amigos getPanelAmigos() {
		return panelAmigos;
	}
	public void setPanelAmigos(Panel_Amigos panelAmigos) {
		this.panelAmigos = panelAmigos;
	}
	public Panel_Contactos getPanelContactos() {
		return panelContactos;
	}
	public void setPanelContactos(Panel_Contactos panelContactos) {
		this.panelContactos = panelContactos;
	}
	public Panel_VerLista getPanelLista() {
		return panelLista;
	}
	public void setPanelLista(Panel_VerLista panelLista) {
		this.panelLista = panelLista;
	}
	public Panel_VerEstadisticas getPanelEstad() {
		return panelEstad;
	}
	public void setPanelEstad(Panel_VerEstadisticas panelEstad) {
		this.panelEstad = panelEstad;
	}
	public Panel_Inicio getPanelInicio() {
		return panelInicio;
	}
	public void setPanelInicio(Panel_Inicio panelInicio) {
		this.panelInicio = panelInicio;
	}
	
	
	
	



}
