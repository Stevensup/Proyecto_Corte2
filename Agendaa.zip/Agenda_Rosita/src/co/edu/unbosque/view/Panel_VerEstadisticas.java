package co.edu.unbosque.view;

import java.awt.Font;

import javax.swing.JButton;
import javax.swing.JPanel;

public class Panel_VerEstadisticas extends JPanel {
	private JButton btRegistrar4;
	private JButton btRegresar4; 
	
	
	public Panel_VerEstadisticas() {
setLayout(null);
		
		start();
		
		setVisible(false);
	}
	public void start() {
		//Regresar
				btRegresar4 = new JButton("Regresar");
				btRegresar4.setBounds(520, 410, 200, 30);
				btRegresar4.setFont(new Font("arial", Font.PLAIN, 30));
				add(btRegresar4);
				
				
	}
	public JButton getBtRegistrar4() {
		return btRegistrar4;
	}
	public void setBtRegistrar4(JButton btRegistrar4) {
		this.btRegistrar4 = btRegistrar4;
	}
	public JButton getBtRegresar4() {
		return btRegresar4;
	}
	public void setBtRegresar4(JButton btRegresar4) {
		this.btRegresar4 = btRegresar4;
	}
	

}
