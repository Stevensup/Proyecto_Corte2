package co.edu.unbosque.model;

import java.io.Serializable;

public class Amigo implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String nombre;
	private String pais;
	private String correo;
	private String telefono;
	
	
	public Amigo(String nombre, String pais, String correo, String telefono) {
		this.nombre = nombre;
		this.pais = pais;
		this.correo = correo;
		this.telefono = telefono;
	}


	public String getNombre() {
		return nombre;
	}


	public void setNombre(String nombre) {
		this.nombre = nombre;
	}


	public String getPais() {
		return pais;
	}


	public void setPais(String pais) {
		this.pais = pais;
	}


	public String getCorreo() {
		return correo;
	}


	public void setCorreo(String correo) {
		this.correo = correo;
	}


	public String getTelefono() {
		return telefono;
	}


	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}


	@Override
	public String toString() {
		return "Amigo [nombre=" + nombre + ", pais=" + pais + ", correo=" + correo + ", telefono=" + telefono + "]";
	}
	
	





}
