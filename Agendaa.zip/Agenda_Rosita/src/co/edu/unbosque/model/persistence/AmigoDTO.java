package co.edu.unbosque.model.persistence;

import java.io.File;
import java.util.ArrayList;

import co.edu.unbosque.model.Amigo;



public class AmigoDTO {
	private ArrayList<Amigo> amigo;
    private AmigoDAO amigo_dao;
    private File file = new File("Archivos/amigos.dat");
    private Archivo archivo;
    
    public AmigoDTO(){
        amigo = new ArrayList<Amigo>();
        archivo = new Archivo(file);
        amigo_dao = new AmigoDAO(archivo);
        amigo = archivo.leerArchivo(file);
    }

    public ArrayList<Amigo> getVeterinaria() {
        return amigo;
    }

    public void setAmigo(ArrayList<Amigo> amigo) {
        this.amigo = amigo;
    }

    public AmigoDAO getAmigo_dao() {
        return amigo_dao;
    }

    public void setAmigo_dao(AmigoDAO amigo_dao) {
        this.amigo_dao = amigo_dao;
    }

    public File getFile() {
        return file;
    }

    public void setFile(File file) {
        this.file = file;
    }

    public Archivo getArchivo() {
        return archivo;
    }

    public void setArchivo(Archivo archivo) {
        this.archivo = archivo;
    }
    
    
}



