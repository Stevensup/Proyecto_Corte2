package co.edu.unbosque.model.persistence;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Properties;

import co.edu.unbosque.model.ContactoAmigo;

public class Archivos {

}
	
/*	private ObjectInputStream entrada;
    private ObjectOutputStream salida;
	
	public Archivos(Serializable string) {
		File archivo1 = new File("/Archivos/amigos.dat");
		File archivo2 = new File("contactos.dat");
        if (!archivo1.exists()) {
            try {
                archivo1.createNewFile();
            } catch (IOException ex) {

            }
        }
        if(!archivo2.exists()) {
        	try {
        		archivo2.createNewFile();
        	}catch (IOException ex) {
        		
        	}
        }
    }
	public void leerProperties() {
		
	    Properties prop = new Properties();
	    try {
	        FileInputStream fis = new FileInputStream("modelo/agendaFisica.properties");
	        prop.load(fis);
	        fis.close();
	        
	        //Aquí puedes imprimir los valores leídos del archivo
	        System.out.println("Contenido del archivo agendaFisica.properties:");
	        for (String key : prop.stringPropertyNames()) {
	            String value = prop.getProperty(key);
	            System.out.println(key + ": " + value);
	        }
	        
	    } catch (IOException ex) {
	        ex.printStackTrace();
	    }
	}
	    
	

    

	 public void escribirArchivo(String nombre, String telefono, String pais, String correo, ArrayList<ContactoAmigo> contactosAmigos, String archivo1) {
	        try {
	            salida = new ObjectOutputStream(new FileOutputStream(archivo1));
	            salida.writeObject(contactosAmigos);
	            salida.close();
	            
	        } catch (FileNotFoundException ex) {
	            ex.printStackTrace();
	        } catch (IOException ex) {
	            ex.printStackTrace();
	        }
	    }

	 public ArrayList<ContactoAmigo> leerArchivo(String archivo1) {
	        ArrayList<ContactoAmigo> contactosAmigos = new ArrayList<ContactoAmigo>();
	        if (archivo1.length() != 0) {
	            try {
	                entrada = new ObjectInputStream(new FileInputStream(archivo1));
	                contactosAmigos = (ArrayList<ContactoAmigo>) entrada.readObject();
	                entrada.close();
	            } catch (FileNotFoundException ex) {
	                ex.printStackTrace();
	            } catch (IOException ex) {
	                ex.printStackTrace();
	            } catch (ClassNotFoundException ex) {
	                ex.printStackTrace();
	            }
	        }
	        return contactosAmigos;
	    }
    public void escribirArchivoContactos(String nombre, String telefono, String pais, String correo, ArrayList<ContactoAmigo> contactosAmigos, File file) {
        try {
            salida = new ObjectOutputStream(new FileOutputStream(file));
            salida.writeObject(contactosAmigos);
            salida.close();
        } catch (FileNotFoundException ex) {
            ex.printStackTrace();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    public ObjectInputStream getEntrada() {
        return entrada;
    }

    public void setEntrada(ObjectInputStream entrada) {
        this.entrada = entrada;
    }

    public ObjectOutputStream getSalida() {
        return salida;
    }

    public void setSalida(ObjectOutputStream salida) {
        this.salida = salida;
    }

		// TODO Auto-generated method stub
		
	
}
*/

	


