package co.edu.unbosque.model.persistence;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

import co.edu.unbosque.model.Amigo;



public class Archivo {

    private ObjectInputStream entrada;
    private ObjectOutputStream salida;

    public Archivo(File file) {
        if (!file.exists()) {
            try {
                file.createNewFile();
            } catch (IOException ex) {

            }
        }
    }

    public void escribirArchivo(ArrayList<Amigo> amigo ) {
        try {
        	
        	File file = new File("amigos.dat");
        	
        	System.out.println("creando el objectOutpStream");
            salida = new ObjectOutputStream(new FileOutputStream(file));
            System.out.println("Escribiendo los datos en el archivo...");
            salida.writeObject(amigo);
            salida.close();
            System.out.println("El archivo se ha cerrado correctamente.");
        } catch (FileNotFoundException ex) {
            ex.printStackTrace();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    public ArrayList<Amigo> leerArchivo(File file) {
        ArrayList<Amigo> amigo = new ArrayList<Amigo>();
        if (file.length() != 0) {
            try {
                entrada = new ObjectInputStream(new FileInputStream(file));
                amigo = (ArrayList<Amigo>) entrada.readObject();
                entrada.close();
            } catch (FileNotFoundException ex) {
                ex.printStackTrace();
            } catch (IOException ex) {
                ex.printStackTrace();
            } catch (ClassNotFoundException ex) {
                ex.printStackTrace();
            }
        }
        return amigo;
    }

    public ObjectInputStream getEntrada() {
        return entrada;
    }

    public void setEntrada(ObjectInputStream entrada) {
        this.entrada = entrada;
    }

    public ObjectOutputStream getSalida() {
        return salida;
    }

    public void setSalida(ObjectOutputStream salida) {
        this.salida = salida;
    }
   
}


