package co.edu.unbosque.model.persistence;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import co.edu.unbosque.model.Amigo;



public class AmigoDAO {
	private Archivo archivo;

    public AmigoDAO(Archivo archivo) {
        this.archivo = archivo;
    }

    public boolean agregarAmigo(String nombre, String pais, String correo, String telefono, ArrayList<Amigo> amigo, File file) {
        Amigo nueva = new Amigo(nombre, pais, correo, telefono);
        if (buscarAmigo(nombre, amigo) == null) {
            amigo.add(nueva);
            archivo.escribirArchivo(amigo);
            return true;
        } else {
            return false;
        }
    }

    public Amigo buscarAmigo(String nombre, ArrayList<Amigo> amigo) {
        Amigo encontrada = null;

        if (!amigo.isEmpty()) {
            //for elemento in lista:
            for (Amigo amigo1 : amigo) {
                if (nombre.equals(amigo1.getNombre())) {
                    encontrada = amigo1;
                }
            }
        }

        return encontrada;
    }

    public boolean eliminarAmigo(String nombre, ArrayList<Amigo> amigo, File file) {
        try {
            Amigo m = buscarAmigo(nombre, amigo);
            if (m == null) {
                return false;
            } else {
                amigo.remove(m);
                file.delete();
                file.createNewFile();
                archivo.escribirArchivo(amigo);
                return true;
            }
        } catch (IOException ex) {
            ex.printStackTrace();
            return false;
        }
    }

    public boolean modificarAmigo(String nombre, String nombre2,String pais, String correo, String telefono, ArrayList<Amigo> amigo, File file) {
        Amigo encontrada = buscarAmigo(nombre, amigo);
        try {
            if (encontrada != null) {
                eliminarAmigo(nombre, amigo, file);
                encontrada.setNombre(nombre2);
                encontrada.setPais(pais);
                encontrada.setCorreo(correo);
                encontrada.setTelefono(telefono);
                amigo.add(encontrada);
                file.delete();
                file.createNewFile();
                archivo.escribirArchivo(amigo);
                return true;
            } else {
                return false;
            }
        } catch (IOException ex) {
            ex.printStackTrace();
            return false;
        }
    }

    public String mostrarListado(File file) {
        ArrayList<Amigo> amigo = archivo.leerArchivo(file);
        String listado = "";
        for (Amigo amigo1 : amigo) {
            listado = listado.concat(amigo.toString() + "\n");
        }
        return listado;
    }

}



