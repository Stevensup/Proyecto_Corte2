package co.edu.unbosque.controller;


import co.edu.unbosque.model.Amigo;
import co.edu.unbosque.model.ContactoAmigo;
import co.edu.unbosque.model.persistence.AmigoDTO;
import co.edu.unbosque.model.persistence.Archivo;
import co.edu.unbosque.model.persistence.Archivos;
import co.edu.unbosque.view.Panel_Amigos;
import co.edu.unbosque.view.Panel_Contactos;
import co.edu.unbosque.view.Panel_Inicio;
import co.edu.unbosque.view.Panel_VerEstadisticas;
import co.edu.unbosque.view.Panel_VerLista;
import co.edu.unbosque.view.Ventana;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.ArrayList;
// import co.edu.unbosque.model.ContactoTrabajo;
import java.util.Scanner;



public class Controller implements ActionListener{
	
	private Panel_Amigos panelAmigos;
	private Panel_Contactos panelContactos;
	private Panel_VerLista panelLista;
	private Panel_VerEstadisticas panelEstad;
	private Panel_Inicio panelInicio;
	private File archivoAmigos;
	private AmigoDTO dto;
	
	private Ventana ven;
	private Archivo arc;
	
	
	public Controller() {
		archivoAmigos = new File("amigos.dat");
		arc = new Archivo(archivoAmigos);
		ven = new Ventana();
		dto = new AmigoDTO();
		panelAmigos = new Panel_Amigos();
		panelContactos = new Panel_Contactos();
		panelLista = new Panel_VerLista();
		panelEstad = new Panel_VerEstadisticas();
		
		
		start();
	}
	
	public void start() {
		
		setListeners();
		
	}
	
	public void setListeners() {
		ven.getPanelInicio().getBotAmigos().addActionListener(this);
		ven.getPanelInicio().getBotAmigos().setActionCommand("BtnAmigos");
		
		ven.getPanelInicio().getBotContactos().addActionListener(this);
		ven.getPanelInicio().getBotContactos().setActionCommand("BtnContactos");
		
		ven.getPanelInicio().getBotLista().addActionListener(this);
		ven.getPanelInicio().getBotLista().setActionCommand("BtnLista");
		
		ven.getPanelInicio().getBotEstad().addActionListener(this);
		ven.getPanelInicio().getBotEstad().setActionCommand("BtnEstad");
	
		
		
		//Inquilino
		ven.getPanelAmigos().getBtRegistrar1().addActionListener(this);
		ven.getPanelAmigos().getBtRegistrar1().setActionCommand("btRegistrar1");
		
		//propiedad
		ven.getPanelContactos().getbtRegistrar2().addActionListener(this);
		ven.getPanelContactos().getbtRegistrar2().setActionCommand("btRegistrar2");
		
	//BtRegresar: inquilino
		ven.getPanelAmigos().getBtRegresar1().addActionListener(this);
		ven.getPanelAmigos().getBtRegresar1().setActionCommand("btRegresar1");
		//BtRegresar2: propiedad
		ven.getPanelContactos().getBtRegresar2().addActionListener(this);
		ven.getPanelContactos().getBtRegresar2().setActionCommand("btRegresar2");
		
		//BtRegresar3: lista
		ven.getPanelLista().getBtRegresar3().addActionListener(this);
		ven.getPanelLista().getBtRegresar3().setActionCommand("btRegresar3");
		
		//BtRegresar4: estadisticas
		
		ven.getPanelEstad().getBtRegresar4().addActionListener(this);
		ven.getPanelEstad().getBtRegresar4().setActionCommand("btRegresar4");
		
		
		
		
	
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		switch(e.getActionCommand()) {
		case "BtnAmigos":
			//Cambiar de interfaz a la del amigo
			ven.getPanelInicio().setVisible(false);
			ven.getPanelAmigos().setVisible(true);
			//System.out.println("Funciona");
			break;
			
		case "BtnContactos":
			//Cambiar interfaz a la interfaz de registro de propiedad
			ven.getPanelInicio().setVisible(false);
			ven.getPanelContactos().setVisible(true);
			break;
			
		case "btRegistrar1":
			
			String nombre = ven.getPanelAmigos().getJtNombre().getText();
			String telefono = ven.getPanelAmigos().getJtTelefono().getText();
			String pais= ven.getPanelAmigos().getJtPais().getText(); 
			String correo= ven.getPanelAmigos().getJtCorreo().getText();
			arc.escribirArchivo(null);
			
			
			
			//metodo para el JTextArea:
			ven.getPanelAmigos().getJtaResultados1().append("NOMBRE: "+nombre + "\n ");
			ven.getPanelAmigos().getJtaResultados1().append("DOCUMENTO: "+telefono + "\n");
			ven.getPanelAmigos().getJtaResultados1().append("FECHA DE PAGO: "+pais + "\n");
			ven.getPanelAmigos().getJtaResultados1().append("CUOTA MENUAL: "+correo + "\n");
			
			

		    panelAmigos.getJtNombre().setText("");
		    panelAmigos.getJtTelefono().setText("");
		    panelAmigos.getJtPais().setText("");
		    panelAmigos.getJtCorreo().setText("");
		    break;
		    
		/*case "btRegistrar2":
			
			
			String nombre1 = ven.getPanelContactos().getJtNombre().getText();
			String telefono1 = ven.getPanelContactos().getJtTelefono().getText();
			String pais1 = ven.getPanelContactos().getJtPais().getText(); 
			String correo1 = ven.getPanelContactos().getJtCorreo().getText();
		    arc.escribirArchivoContactos(nombre, telefono, pais, correo, null, null);
		    
		    //JTextArea:
		    ven.getPanelContactos().getJtaResultados2().append("NOMBRE: "+nombre + "\n ");
			ven.getPanelContactos().getJtaResultados2().append("Telefono: "+telefono + "\n");
			ven.getPanelContactos().getJtaResultados2().append("Pais: "+pais + "\n");
			ven.getPanelContactos().getJtaResultados2().append("Correo: "+correo + "\n");
			
		   
			
		
		    panelContactos.getJtNombre().setText("");
		    panelContactos.getJtTelefono().setText("");
		    panelContactos.getJtPais().setText("");
		    panelContactos.getJtCorreo().setText("");
		    
		    
		    break;
		    */
		case "btRegresar1":
			ven.getPanelAmigos().setVisible(false);
			ven.getPanelInicio().setVisible(true);
			break;
			
		case "btRegresar2":
			ven.getPanelContactos().setVisible(false);
			ven.getPanelInicio().setVisible(true);
			break;
		}
		
		
			
		}
		
	}
	
	
	





